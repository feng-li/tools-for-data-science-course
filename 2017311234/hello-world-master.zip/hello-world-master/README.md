# hello-world
work place
it's my homework land for data science 
